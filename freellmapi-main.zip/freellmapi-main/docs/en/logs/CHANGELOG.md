**English** · [简体中文](../../zh-cn/logs/CHANGELOG.md)

# Changelog

Doc revision history for `docs/logs/`. Most recent first.

| Date | Commit | Change |
| --- | --- | --- |
| 2026-08-23 | `74df985` | Server log viewer in the dashboard, under an Analytics nav menu (#993) |
| 2026-08-22 | `36850e8` | docs(meta): index providers/testing domains and log today's additions (landed via #979) |

> Implementation commits: `74df985` (log viewer feature), `36850e8` (meta indexing, landed via #979).